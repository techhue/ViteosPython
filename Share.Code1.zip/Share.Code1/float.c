#include <stdio.h>

int main() {
	float first  = 90.878789898978;
	float second = 90.8787898989788989483984;

	if (abs(first - second) <= epsilon ) {
		printf("\nNumbers are equal\n");
	} else {
		printf("\nNumbers are Unequal\n");
	}
}


