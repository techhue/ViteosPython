
Install Ubuntu Linux In VirtualBox or VMWare
___________________________________________________________
	Download VirtualBox or VMWare
	Install VirtualBox or VMWare
	Create Virual Machine
	Download Ubuntu Desktop .iso File
	Install Ubuntu On VirtualBox or VMWare Virtual Machine

Install Python
___________________________________________________________
	Download Python From
		https://www.python.org/
	Install Python
	Add Python Directory in PATH Variable

Save Code Here
___________________________________________________________
	YOUR_PATH/Documents/ViteosPython
		hello.py
	Use File Name Without Spaces

Editor To Use
___________________________________________________________
	Sublime Text
	Visual Code

How To Do Python Code
___________________________________________________________
1. Using Python IDLE Shell or Command Prompt or Terminal
		To invoke python shell use following command
			python

2. Using File
	 	Write code in file using your favorite editor
	 	Save File as hello.py file
	 	Use Following command to run hello.py file
	 		python 	YOUR_PATH/Documents/ViteosPython/hello.py

Data Types in Python
___________________________________________________________
	str   : String Type and str Values are Immutable
	int   : Integer Type and int Values are Immutable
	bool  : Bool Type and bool Values are Immutable

	Decimal Types in Python
		float : Python float Type
			It is same as C/C++/Java double Type.
			It means it is Double Precision Floating Pointing Number
			Floating Point Number != Mathematics Real Numbers
			float Values are Immutable

		complex : Float Type
			a + bj where a and b are Python float type
			complex Values are Immutable

		decimal : Decimal Type
			Python Decimal Type == Mathematics Real Numbers
			decimal Values are Immutable

	You can addition between two values of type of
		int and int
		float and float
		float and int 
		string and string 
		list and list
		tuple and tuple
		
		DON'T Use bool type In addition As It's Bad Programming Practice.
			Adding bool and bool can do it. But not recommended
			Adding int and bool can do it. But not recommended
			Adding float and bool can do it. But not recommended

	You Cann't do addition between two values of type of 
		string and int
		string and float
		string and bool

Equality
___________________________________________________________
	Two Numbers are Equal In Mathematics
		a == b iff a - b = 0

	Two Floating Point Numbers are Equal
		a == b iff a - b <= epislon


Python is Dynamic[Runtime] Language
___________________________________________________________
Data Types Nature
	I.  Type Inferencing 
	II. Type Binding

	In case Python of Python Type Inferencing and Binding happens at Runtime
	But in C/C++/Java/C# it happens at compile time.

	Because of this you can change Type of Variable in Python at Runtime
	But in C/C++/Java/C# once fixed(Compiled Time), it is fixed forever.

Python Collection Types
_____________________________________________________________________________________
	tuple: Python Tuple Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Support L->R and R->L members access similar to String
		Tuple Can Be Nested i.e. Can Create tuple of tuple of tuple of and so on...

		NOTE: Tuple members are Immutable


	list: Python List Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Support L->R and R->L members access similar to String
		list Can Be Nested i.e. Can Create list of list of list of and so on...

		NOTE: List members are Mutable


	NOTE: list(sequence) and tuple(sequence)
		These functions take one argument and that is a sequence.
		It will iterate on sequence, pick each member and add in tuple/list 

		Examples of Python Sequences Are:
			Python String, Tuple and List are Sequences, Hence can be passed as argument
			to list() and tuple() functions.

			There are two more Sequences are there in Python called bytes and bytes array,
			but you are not going to use it in most common scenarios.

	set: Python Set Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Set Can Be Nested i.e. Can Create set of set of set of and so on...

		NOTE: Set members are Immutable

		Python Set == Mathematics Set
			Collection of Objects
			Duplicate Are Not Allowed in Set
			Order in Set Doesn't Matters
_____________________________________________________________________________________




