
greeting = "Hello World!"
print(greeting)

