
t = (10, 20, 30, 40, 50, 60, 70)

# print("Items in Tuple: {0}".format(t) )

# #item is variable name of your choice
# for item in t:
# 	print(item)

# tt = ((10, 20, 30, 40, 50), (100, 200, 300), ("Ding", "Dong"), "Ming", "Mong")
# print("\nItems in Tuple: {0}".format(tt) )

# #item is variable name of your choice
# for item in tt:
# 	print(item)
# 	for something in item:
# 		print(something)


marks = ((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))

#Style - Good One
for mark in marks:
	print( mark[0] + mark[1] )

#Style - Better One
MATH, ENGLISH = (0, 1)
for mark in marks:
	print(mark[MATH] + mark[ENGLISH])

#Style - Best One
for math, english in marks:
	print(math + english)




