
>>> greeting + name
'Hello World! Ashwarya Rai'
>>> 
>>> 
>>> greeting
'Hello World!'
>>> name
' Ashwarya Rai'
>>> a
40
>>> b
30
>>> 
>>> 
>>> c = "90"
>>> 
>>> c
'90'
>>> type(c)
<class 'str'>
>>> 
>>> cc = int(c)
>>> 
>>> cc
90
>>> type(cc)
<class 'int'>
>>> 
>>> 
>>> f = 9.80
>>> type(f)
<class 'float'>
>>> 
>>> g = 1.10
>>> 
>>> f + g
10.9
>>> 
>>> 
>>> ff = f + g
>>> 
>>> ff
10.9
>>> type(ff)
<class 'float'>
>>> greeting
'Hello World!'
>>> 
>>> greeting[0]
'H'
>>> 
>>> 
>>> greeting[1]
'e'
>>> 
>>> greeting[2]
'l'
>>> 
>>> greeting[10]
'd'
>>> 
>>> 
>>> greeting[11]
'!'
>>> greeting[12]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: stri




>>> greeting
'Hello World!'
>>> 
>>> 
>>> 
>>> greeting[2 : 6]
'llo '
>>> 
>>> greeting[::]
'Hello World!'
>>> 
>>> length = len(greeting)
>>> 
>>> greeting[0: length : 1 ]
'Hello World!'
>>> 
>>> 
>>> 
>>> 
>>> greeting[::]
'Hello World!'
>>> greeting[0: length : 1 ]
'Hello World!'
>>> 
>>> 
>>> greeting[:: 2 ]
'HloWrd'
>>> 
>>> 
>>> greeting[::3]
'HlWl'
>>> 
>>> 
>>> greeting[:: -1 ]
'!dlroW olleH'
>>> 
>>> 
>>> greeting[:: -2 ]
'!lo le'
>>> 
>>> 


>>> f1 = 98.989898908898989898989898989777
>>> f2 = 98.9898989088989898989898989897778938493849384
>>> 
>>> if f1 == f2:
...     print("They are equal")
... else:
...     print("Unequal...")
... 
They are equal
>>> 
>>> 
>>>  
... 
>>> import sys
>>> 
>>> sys.float_info.epsilon
2.220446049250313e-16
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> first  = 90.878789898978
>>> second = 90.8787898989788989483984
>>> 
>>> 
>>> first
90.878789898978
>>> 
>>> second
90.8787898989789
>>> 
>>> 
>>> import decimal
>>> d1 = decimal.Decimal("90.878789898978")
>>> d2 = decimal.Decimal("90.8787898989788989483984")
>>> 
>>> d1
Decimal('90.878789898978')
>>> d2
Decimal('90.8787898989788989483984')
>>> 
>>> d1 - d2
Decimal('-8.989483984E-13')
>>> 
>>> first - second
-8.952838470577262e-13
>>> d2 = decimal.Decimal("90.878789898978898948398489839898989898989859489548954895485948594854985498498549777")
>>> 
>>> d2
Decimal('90.878789898978898948398489839898989898989859489548954895485948594854985498498549777')
>>> 




>>> first  = 90.878789898978
>>> second = 90.8787898989788989483984
>>> 
>>> 
>>> first
90.878789898978
>>> 
>>> second
90.8787898989789
>>> 
>>> 
>>> import decimal
>>> d1 = decimal.Decimal("90.878789898978")
>>> d2 = decimal.Decimal("90.8787898989788989483984")
>>> 
>>> d1
Decimal('90.878789898978')
>>> d2
Decimal('90.8787898989788989483984')
>>> 
>>> d1 - d2
Decimal('-8.989483984E-13')
>>> 
>>> first - second
-8.952838470577262e-13
>>> d2 = decimal.Decimal("90.878789898978898948398489839898989898989859489548954895485948594854985498498549777")
>>> 
>>> d2
Decimal('90.878789898978898948398489839898989898989859489548954895485948594854985498498549777')
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> d2
Decimal('90.878789898978898948398489839898989898989859489548954895485948594854985498498549777')
>>> 
>>> d2 * 2
Decimal('181.7575797979577978967969797')
>>> 
>>> 
>>> d2 * decimal.Decimal("2")
Decimal('181.7575797979577978967969797')
>>> 
>>> 
>>> 
>>> 
>>> 
>>> d1
Decimal('90.878789898978')
>>> d2
Decimal('90.878789898978898948398489839898989898989859489548954895485948594854985498498549777')
>>> d1 + d2
Decimal('181.7575797979568989483984898')
>>> 
>>> 
>>> 
>>> 
>>> 
>>> d2 / d1
Decimal('1.000000000000009891729406709')
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> t = (10, 20, 30, 40, 50, 60, 70)
>>> 
>>> t
(10, 20, 30, 40, 50, 60, 70)
>>> 
>>> type(t)
<type 'tuple'>
>>> 
>>> 
>>> t[0]
10
>>> t[1]
20
>>> 
>>> t[4]
50
>>> 
>>> t[len(t)-1]
70
>>> 
>>> 
>>> tt = (10, 20, 30, "Ding", "Dong")
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> tt[0]
10
>>> tt[1]
20
>>> tt[2]
30
>>> tt[3]
'Ding'
>>> 
>>> tt[4]
'Dong'
>>> 
>>> tt[5]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> tt[-1]
'Dong'
>>> tt[-2]
'Ding'
>>> 
>>> tt[-5]
10
>>> 
>>> 
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> len(tt)
5
>>> 
>>> tt[2:4]
(30, 'Ding')
>>> 
>>> tt[::2]
(10, 30, 'Dong')
>>> 
>>> tt[::-1]
('Dong', 'Ding', 30, 20, 10)
>>> 
>>> 
>>> t = ((10, 20, 30, 40), (100, 200), ("Ding", "Dong"))
>>> 
>>> t[0]
(10, 20, 30, 40)
>>> t[1]
(100, 200)
>>> t[2]
('Ding', 'Dong')
>>> type(t[2])
<type 'tuple'>
>>> 
>>> t[0][1]
20
>>> 
>>> t[1][1]
200
>>> 
>>> t[2][1]
'Dong'
>>> t[2][1][0]
'D'
>>> 
>>> t[2][1][1]
'o'
>>> 
>>> 
>>> 
>>> 
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> tt[0]
10
>>> 
>>> tt[0] = 100
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> greeting
'Hello World!'
>>> greeting[0]
'H'
>>> 
>>> greeting[0] = "h"
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object does not support item assignment
>>> 
>>> greeting = "Guten Tag!"
>>> 
>>> greeting[0] = 'g'
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object does not support item assignment
>>> 
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> 
>>> 
>>> t[::-1]
(('Ding', 'Dong'), (100, 200), (10, 20, 30, 40))
>>> 
>>> 
>>> t[::-1][2]
(10, 20, 30, 40)
>>> 
>>> t[::-1][2][::-1]
(40, 30, 20, 10)
>>> 
>>> t[::-1]
(('Ding', 'Dong'), (100, 200), (10, 20, 30, 40))
>>> 
>>> t[::-1][2]
(10, 20, 30, 40)
>>> t[::-1][2][::-1]
(40, 30, 20, 10)
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> 
>>> 
>>> 
>>> greeting
'Guten Tag!'
>>> 
>>> a = 908
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> 
>>> 10 in tt
True
>>> 
>>> 100 in tt
False
>>> 
>>> len(tt)
5
>>> 
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> len(t)
3
>>> 
>>> len(t[0])
4
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> "Ding" in tt
True
>>> 
>>> "Ming" in tt
False
>>> 
>>> 10 in t
False
>>> 
>>> 10 in t[0]
True
>>> 
>>> "Ding" in t
False
>>> "Ding" in t[2]
True
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> (10, 20, 30, 40) in t
True
>>> (100, 200, 300) in t
False
>>> 
>>> (100, 200) in t
True
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> 
>>> for item in tt:
...     print(item)
... 
10
20
30
Ding
Dong
>>> 
>>> for item in t:
...     print(item)
... 
(10, 20, 30, 40)
(100, 200)
('Ding', 'Dong')
>>> 
>>> 
>>> for item in t:
...   print(item)
... 
(10, 20, 30, 40)
(100, 200)
('Ding', 'Dong')
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Guten Tag!'
>>> 
>>> for item in greeting:
...     print(item)
... 
G
u
t
e
n
 
T
a
g
!
>>> 
>>> 
>>> 
>>> 
>>> l = [10, 20, 30, 40, 50, 60, 70, 80, 90]
>>> 
>>> type(l_
... 
... 
KeyboardInterrupt
>>> 
>>> type(l)
<type 'list'>
>>> 
>>> l[0]
10
>>> l[1]
20
>>> l[len(l) - 1 ]
90
>>> 
>>> l[3:7]
[40, 50, 60, 70]
>>> 
>>> l[3:]
[40, 50, 60, 70, 80, 90]
>>> l[3::2]
[40, 60, 80]
>>> 
>>> 
>>> l[3::-1]
[40, 30, 20, 10]
>>> 
>>> l[::-1]
[90, 80, 70, 60, 50, 40, 30, 20, 10]
>>> 
>>> l = [100, 200, "Ding" , "Dong"]
>>> 
>>> 
>>> l[0]
100
>>> 
>>> l[0] = 1000
>>> 
>>> l
[1000, 200, 'Ding', 'Dong']
>>> 
>>> 



>>> l = [10, 20, 30, 40, 50, 60, 70, 80, 90]
>>> 
>>> type(l_
... 
... 
KeyboardInterrupt
>>> 
>>> type(l)
<type 'list'>
>>> 
>>> l[0]
10
>>> l[1]
20
>>> l[len(l) - 1 ]
90
>>> 
>>> l[3:7]
[40, 50, 60, 70]
>>> 
>>> l[3:]
[40, 50, 60, 70, 80, 90]
>>> l[3::2]
[40, 60, 80]
>>> 
>>> 
>>> l[3::-1]
[40, 30, 20, 10]
>>> 
>>> l[::-1]
[90, 80, 70, 60, 50, 40, 30, 20, 10]
>>> 
>>> l = [100, 200, "Ding" , "Dong"]
>>> 
>>> 
>>> l[0]
100
>>> 
>>> l[0] = 1000
>>> 
>>> l
[1000, 200, 'Ding', 'Dong']
>>> 
>>> 
>>> 
>>> 
>>> l = [[10, 20, 30, 40, 50], [100, 200, 300], ["Ding", "Dong"], "Ming", "Mong"]
>>> 
>>> l
[[10, 20, 30, 40, 50], [100, 200, 300], ['Ding', 'Dong'], 'Ming', 'Mong']
>>> 
>>> type(l)
<type 'list'>
>>> 
>>> 
>>> 
>>> 
>>> l[0]
[10, 20, 30, 40, 50]
>>> 
>>> type(l[0])
<type 'list'>
>>> 
>>> for item in l:
...     print(item)
... 
[10, 20, 30, 40, 50]
[100, 200, 300]
['Ding', 'Dong']
Ming
Mong
>>> 
>>> 
>>> ll = [[10, 20, 30, 40, 50], (100, 200, 300), ["Ding", "Dong", (99, 88)], "Ming", "Mong"]
>>> 
>>> ll
[[10, 20, 30, 40, 50], (100, 200, 300), ['Ding', 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> for item in ll:
...     print(item)
... 
[10, 20, 30, 40, 50]
(100, 200, 300)
['Ding', 'Dong', (99, 88)]
Ming
Mong
>>> 
>>> 
>>> 
>>> ll[0]
[10, 20, 30, 40, 50]
>>> 
>>> ll[0][0]
10
>>> 
>>> ll[0][0] = 1000
>>> 
>>> ll
[[1000, 20, 30, 40, 50], (100, 200, 300), ['Ding', 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> ll[1][0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> 
>>> 
>>> ll[2][0] = 1000
>>> 
>>> ll
[[1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> ll[2][2][0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> 
>>> 
>>> dir(())
['__add__', '__class__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__getslice__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> 
>>> 
>>> 
>>> dir(tuple)
['__add__', '__class__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__getslice__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> 
>>> 
>>> 
>>> t
((10, 20, 30, 40), (100, 200), ('Ding', 'Dong'))
>>> 
>>> t.count(10)
0
>>> 
>>> 
>>> t[0].count(10)
1
>>> 
>>> t.count((100, 200))
1
>>> 
>>> 
>>> t.index((100, 200))
1
>>> 
>>> 
>>> dir(tuple)
['__add__', '__class__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__getslice__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> 
>>> dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__delslice__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getslice__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__setslice__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> 
>>> l
[[10, 20, 30, 40, 50], [100, 200, 300], ['Ding', 'Dong'], 'Ming', 'Mong']
>>> 
>>> l.reverse()
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50]]
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50]]
>>> 
>>> l.append("Ting")
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Ting']
>>> 
>>> l.append("Tong")
>>> 
>>> l.append((1000, 2000))
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Ting', 'Tong', (1000, 2000)]
>>> 
>>> l.remove()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: remove() takes exactly one argument (0 given)
>>> 
>>> 
>>> help(l.remove)

>>> 
>>> 
>>> l.remove("Ting")
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Tong', (1000, 2000)]
>>> 
>>> ll
[[1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> 
>>> for item in ll:
...     l.append(item)
... 
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Tong', (1000, 2000), [1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> 
>>> 
>>> dir([].insert)
['__call__', '__class__', '__cmp__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__le__', '__lt__', '__module__', '__name__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__self__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__']
>>> 
>>> dir([])
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__delslice__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getslice__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__setslice__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> help([].insert)

>>> 
>>> 
>>> l
['Mong', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Tong', (1000, 2000), [1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> l.insert(1, "Hello!")
>>> 
>>> l
['Mong', 'Hello!', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Tong', (1000, 2000), [1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> 
>>> 
>>> l.count("Mong")
2
>>> 
>>> 
>>> 
>>> l.count("Dong")
0
>>> 
>>> 
>>> 
>>> 
>>> l.count("Mong")
2
>>> 
>>> dir([])
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__delslice__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getslice__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__setslice__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> help([].extend)

>>> 
>>> 
>>> 
>>> first = [100, 200, 300]
>>> 
>>> first
[100, 200, 300]
>>> 
>>> second = [1000, 2000]
>>> 
>>> first.append(second)
>>> 
>>> first
[100, 200, 300, [1000, 2000]]
>>> 
>>> 
>>> first.extend(second)
>>> 
>>> first
[100, 200, 300, [1000, 2000], 1000, 2000]
>>> 
>>> 
>>> dir([])
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__delslice__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getslice__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__setslice__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> 
>>> l
['Mong', 'Hello!', 'Ming', ['Ding', 'Dong'], [100, 200, 300], [10, 20, 30, 40, 50], 'Tong', (1000, 2000), [1000, 20, 30, 40, 50], (100, 200, 300), [1000, 'Dong', (99, 88)], 'Ming', 'Mong']
>>> 
>>> first
[100, 200, 300, [1000, 2000], 1000, 2000]
>>> 
>>> 
>>> first.pop()
2000
>>> 
>>> first
[100, 200, 300, [1000, 2000], 1000]
>>> first.pop()
1000
>>> 
>>> first
[100, 200, 300, [1000, 2000]]
>>> 
>>> 
>>> 
>>> 

>>> import sys
>>> 
>>> ys.float_info.epsilon
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'ys' is not defined
>>> 
>>> 
>>> sys.float_info.epsilon
2.220446049250313e-16
>>> 
>>> 
>>> 
>>> 
>>> 
>>> math.exp(10, 2)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'math' is not defined
>>> 
>>> 
>>> 
>>> li
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'li' is not defined
>>> li = ['Ding', 'AAA', 1000, 100, 90, 10, 10, -10, -20]
>>> 
>>> 
>>> li
['Ding', 'AAA', 1000, 100, 90, 10, 10, -10, -20]
>>> 
>>> 
>>> li.reverse()
>>> 
>>> 
>>> li
[-20, -10, 10, 10, 90, 100, 1000, 'AAA', 'Ding']
>>> 
>>> li.reverse()
>>> 
>>> li
['Ding', 'AAA', 1000, 100, 90, 10, 10, -10, -20]
>>> 
>>> li.sort()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: '<' not supported between instances of 'int' and 'str'
>>> 
>>> 
>>> li
['Ding', 'AAA', 1000, 100, 90, 10, 10, -10, -20]
>>> 
>>> 
>>> 
>>> 
>>> hair = "black", "brown", "blonde", "red", "white"
>>> 
>>> hair
('black', 'brown', 'blonde', 'red', 'white')
>>> 
>>> type(hair)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> value = ("Ding")
>>> 
>>> value
'Ding'
>>> type(value)
<class 'str'>
>>> value = ("Ding",)
>>> 
>>> value
('Ding',)
>>> type(value)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 7 + 4 * 10
47
>>> 
>>> 
>>> (7 + 4) * 10
110
>>> 
>>> value = ("Ding")
>>> 
>>> 
>>> value
'Ding'
>>> type(value)
<class 'str'>
>>> 
>>> value = ("Ding",)
>>> 
>>> value
('Ding',)
>>> type(value)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> a = int()
>>> 
>>> a
0
>>> type(a)
<class 'int'>
>>> 
>>> s = str()
>>> 
>>> s
''
>>> type(s)
<class 'str'>
>>> 
>>> s = ""
>>> 
>>> t = tuple()
>>> 
>>> t
()
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> f = float()
>>> 
>>> f
0.0
>>> type(f)
<class 'float'>
>>> 
>>> b = bool()
>>> 
>>> b
False
>>> 
>>> l  = list()
>>> 
>>> l
[]
>>> type(l)
<class 'list'>
>>> 
>>> 



>>> 
>>> hair = "black", "brown", "blonde", "red", "white"
>>> 
>>> hair
('black', 'brown', 'blonde', 'red', 'white')
>>> 
>>> type(hair)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> value = ("Ding")
>>> 
>>> value
'Ding'
>>> type(value)
<class 'str'>
>>> value = ("Ding",)
>>> 
>>> value
('Ding',)
>>> type(value)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 7 + 4 * 10
47
>>> 
>>> 
>>> (7 + 4) * 10
110
>>> 
>>> value = ("Ding")
>>> 
>>> 
>>> value
'Ding'
>>> type(value)
<class 'str'>
>>> 
>>> value = ("Ding",)
>>> 
>>> value
('Ding',)
>>> type(value)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> a = int()
>>> 
>>> a
0
>>> type(a)
<class 'int'>
>>> 
>>> s = str()
>>> 
>>> s
''
>>> type(s)
<class 'str'>
>>> 
>>> s = ""
>>> 
>>> t = tuple()
>>> 
>>> t
()
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> f = float()
>>> 
>>> f
0.0
>>> type(f)
<class 'float'>
>>> 
>>> b = bool()
>>> 
>>> b
False
>>> 
>>> l  = list()
>>> 
>>> l
[]
>>> type(l)
<class 'list'>
>>> 
>>> 
>>> c = 10+20j
>>> 
>>> c
(10+20j)
>>> 
>>> type(c)
<class 'complex'>
>>> 
>>> c = complex()
>>> 
>>> c
0j
>>> c.real
0.0
>>> c.imag
0.0
>>> 
>>> import decimal
>>> 
>>> d = decimal.Decimal()
>>> 
>>> d
Decimal('0')
>>> 
>>> 
>>> 
>>> a = int()
>>> 
>>> 
>>> a = int("890")
>>> 
>>> a
890
>>> 
>>> a = int()
>>> 
>>> a
0
>>> 
>>> a = int("890")
>>> 
>>> a
890
>>> 
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> a = int(90)
>>> 
>>> a
90
>>> a = int(90.89)
>>> 
>>> a
90
>>> 
>>> a = int(True)
>>> 
>>> a
1
>>> 
>>> a = int(False)
>>> 
>>> a
0
>>> 
>>> a = int("890ABC")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: '890ABC'
>>> 
>>> 
>>> 
>>> t = (10, 20, 30)
>>> 
>>> l = list(t)
>>> 
>>> l
[10, 20, 30]
>>> 
>>> 
>>> l
[10, 20, 30]
>>> 
>>> tt = tuple(l)
>>> 
>>> tt
(10, 20, 30)
>>> 
>>> 
>>> 
>>> l = list("Hello World")
>>> 
>>> l
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
>>> 
>>> help(list)

>>> 
>>> help(list)

>>> 
>>> 
>>> 
>>> t = tuple("Hello World")
>>> 
>>> t
('H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd')
>>> 
>>> t = tuple(["Hello", "World"])
>>> 
>>> t
('Hello', 'World')
>>> t = list(["Hello", "World"])
>>> 
>>> t
['Hello', 'World']
>>> 
>>> l = list("Hello World")
>>> l
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
>>> 
>>> 
>>> 
>>> 
>>> a, b = (1, 2)
>>> 
>>> a
1
>>> b
2
>>> 
>>> 
>>> 
>>> a, b = (1, 2, 3)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: too many values to unpack (expected 2)
>>> 
>>> 
>>> t = (1, 2, 3)
>>> 
>>> a, b, c = t
>>> 
>>> a
1
>>> b
2
>>> c
3
>>> 
>>> human = ("Ram", 
... human = ("Ram", 
KeyboardInterrupt
>>> 
>>> 
>>> human = ("Ram", "Kumar", 35)
>>> 
>>> human
('Ram', 'Kumar', 35)
>>> 
>>> firstName = human[0]
>>> 
>>> firstName, lastName, age = human
>>> 
>>> firstName
'Ram'
>>> lastName
'Kumar'
>>> age
35
>>> 
>>> 
>>> 
>>> a = 10
>>> b = 20
>>> 
>>> temp = a
>>> 
>>> a = b
>>> b = temp
>>> 
>>> a
20
>>> b
10
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> b, a = (a, b)
>>> 
>>> b
20
>>> a
10
>>> 
>>> 
>>> t = ((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))
>>> 
>>> marks = ((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))
>>> 
>>> 
>>> marks
((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))
>>> 
>>> 
>>> for mark in marks:
...     print(mark)
... 
(20, 80)
(100, 0)
(90, 90)
(0, 0)
(-10, 10)
>>> 
>>> 
>>> for mark in marks:
...     print(mark[0]+mark[1])
... 
100
100
180
0
0
>>> 
>>> 
>>> 
>>> 
>>> marks
((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))
>>> 
>>> 
>>> for mathMark, englishMark in marks:
...     print(mathMark+englishMark)
... 
100
100
180
0
0
>>> 
>>> 
>>> 
>>> 
>>> t
((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10))
>>> 
>>> t = t + ((30, 30), (40, 40))
>>> 
>>> t
((20, 80), (100, 0), (90, 90), (0, 0), (-10, 10), (30, 30), (40, 40))
>>> 
>>> 
>>> 
>>> 
>>> l 
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
>>> 
>>> l = l + ["Ding", "Dong"]
>>> 
>>> l
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd', 'Ding', 'Dong']
>>> 
>>> 
>>> 
>>> l = l - ["Ding", "Dong"]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unsupported operand type(s) for -: 'list' and 'list'
>>> 
>>> 
>>> 
>>> 
>>> l
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd', 'Ding', 'Dong']
>>> 
>>> 
>>> l[2: 5]
['l', 'l', 'o']
>>> 
>>> 
>>> 
>>> l[2: 5] = None
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only assign an iterable
>>> 
>>> l[2: 5] = []
>>> 
>>> l
['H', 'e', ' ', 'W', 'o', 'r', 'l', 'd', 'Ding', 'Dong']
>>> 
>>> 
>>> 
>>> l[2: 5]
[' ', 'W', 'o']
>>> 
>>> del l[2: 5]
>>> 
>>> l
['H', 'e', 'r', 'l', 'd', 'Ding', 'Dong']


