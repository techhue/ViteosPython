Discussions and Code Samples
___________________________________________________________
	https://github.com/techhue/ViteosPython
	b-ok.xyz
		

Install Ubuntu Linux In VirtualBox or VMWare
___________________________________________________________
	Download VirtualBox or VMWare
	Install VirtualBox or VMWare
	Create Virual Machine
	Download Ubuntu Desktop .iso File
	Install Ubuntu On VirtualBox or VMWare Virtual Machine

Install Python
___________________________________________________________
	Download Python From
		https://www.python.org/
	Install Python
	Add Python Directory in PATH Variable

How to Enable Bash Shell in Windows 10?
___________________________________________________________
	
	
	Save Code Here
___________________________________________________________
	YOUR_PATH/Documents/ViteosPython
		hello.py
	Use File Name Without Spaces

Editor To Use
___________________________________________________________
	Sublime Text
	Visual Code

How To Do Python Code
___________________________________________________________
1. Using Python IDLE Shell or Command Prompt or Terminal
		To invoke python shell use following command
			python

2. Using File
	 	Write code in file using your favorite editor
	 	Save File as hello.py file
	 	Use Following command to run hello.py file
	 		python 	YOUR_PATH/Documents/ViteosPython/hello.py

Data Types in Python
___________________________________________________________
	str   : String Type and str Values are Immutable
	int   : Integer Type and int Values are Immutable
	bool  : Bool Type and bool Values are Immutable

	Decimal Types in Python
		float : Python float Type
			It is same as C/C++/Java double Type.
			It means it is Double Precision Floating Pointing Number
			Floating Point Number != Mathematics Real Numbers
			float Values are Immutable

		complex : Float Type
			a + bj where a and b are Python float type
			complex Values are Immutable

		decimal : Decimal Type
			Python Decimal Type == Mathematics Real Numbers
			decimal Values are Immutable

	You can addition between two values of type of
		int and int
		float and float
		float and int 
		string and string 
		list and list
		tuple and tuple
		
		DON'T Use bool type In addition As It's Bad Programming Practice.
			Adding bool and bool can do it. But not recommended
			Adding int and bool can do it. But not recommended
			Adding float and bool can do it. But not recommended

	You Cann't do addition between two values of type of 
		string and int
		string and float
		string and bool

Equality
___________________________________________________________
	Two Numbers are Equal In Mathematics
		a == b iff a - b = 0

	Two Floating Point Numbers are Equal
		a == b iff a - b <= epislon


Python is Dynamic[Runtime] Language
___________________________________________________________
Data Types Nature
	I.  Type Inferencing 
	II. Type Binding

	In case Python of Python Type Inferencing and Binding happens at Runtime
	But in C/C++/Java/C# it happens at compile time.

	Because of this you can change Type of Variable in Python at Runtime
	But in C/C++/Java/C# once fixed(Compiled Time), it is fixed forever.

Python Collection Types
_____________________________________________________________________________________
	tuple: Python Tuple Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Support L->R and R->L members access similar to String
		Tuple Can Be Nested i.e. Can Create tuple of tuple of tuple of and so on...

		NOTE: Tuple members are Immutable


	list: Python List Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Support L->R and R->L members access similar to String
		list Can Be Nested i.e. Can Create list of list of list of and so on...

		NOTE: List members are Mutable


	NOTE: list(sequence) and tuple(sequence)
		These functions take one argument and that is a sequence.
		It will iterate on sequence, pick each member and add in tuple/list 

		Examples of Python Sequences Are:
			Python String, Tuple and List are Sequences, Hence can be passed as argument
			to list() and tuple() functions.

			There are two more Sequences are there in Python called bytes and bytes array,
			but you are not going to use it in most common scenarios.

	set: Python Set Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
		Set Can Be Nested i.e. Can Create set of set of set of and so on...

		NOTE: Set members are Mutable

		Python Set == Mathematics Set
			Collection of Objects
			Duplicate Are Not Allowed in Set
			Order in Set Doesn't Matters

	dict: Python Map/Dictionary/KeyValuePair Type
		Can Store Heterogenous Kind of Data i.e. Can Store Any Python Type Data
			Key-Value Pair where key is hashable i.e. key can any Immutable Python Object
			and Value can by Any Python Object
			
		dict Can Be Nested i.e. Can Create dict of dict of dict of and so on...

		NOTE: dict members are Mutable
			  Mutable Python Objects are not hashable. e.g. list, dict, set etc..

list Comprehension
_____________________________________________________________________________________
	>>> numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	>>> squares = [ n * n for n in numbers ]
	>>> squares
	[1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

	It is Smiliar to Following Logic...

	numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	squares = []
	for number in numbers:
		squares = squares + [ number * number ]
	print(squares)

	Similarly....

	>>> squares = [ n * n for n in numbers if n % 2 == 0 ]
	>>> squares
	[4, 16, 36, 64, 100]

	It is Smiliar to Following Logic...

	numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	squares = []
	for number in numbers:
		if number % 2 == 0:
			squares = squares + [ number * number ]

	print(squares)


set Comprehension
___________________________________________________________________________
#PROBLEM: Filter Unique HTML Files

	#Using Set Compresension
	htmlFiles = { file for file in files if file.lower().endswith((".htm", ".html")) }

	#Above Code is Same As Following Code...
	files = ["ding.html", "ting.htm", "ding.html", "Dong.HTML", "tong.c", "mong.java" ]
	htmlFiles = {}
	for file in files:
		if file.lower().endswith((".html", ".htm")):
			htmlFiles.add(file)
	print(set(htmlFiles)

dict Comprehension
___________________________________________________________________________
	#PROBLEM: Calculate Square of Each Number 1 to 10 and Store In Dictionary

	#Using Dictionary Comprehesion
	>>> squares = { n : n * n for n in range(1, 11) }
	>>> squares
	{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}

	#Above Code is Same As Following Code...
	numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	squares = {}
	for number in numbers:
		if number % 2 == 0:
			squares[number] = number * number
	print(squares)

CODING EXCERCISE
___________________________________________________________________________
#PROBLEM: Calculate Factorial of Each Number 1 to 10
	- Using General Way
	- Using List Comprehension
	- Using Set Comprehension
	- Using Dictionary Comprehension

Sequences And Iterables
___________________________________________________________________________
	Sequence is a One Dimentional Entity
	Python has builtin Sequences
		e.g. str, tuple and list are Sequences In Python
	
	All Sequences are Iterable 
		means You can use for-in loop with it.

	For-In Loop Syntax

		for item in Iterable:
			experiment with item

		as Sequences are also Iterable in Python so following is also possible

		for item in Sequence:
			experiment with item

CODING EXCERCISE
___________________________________________________________________________
#PROBLEM: Write A Calculator Function to Calculate N Numbers
#		  Sum, Product, Average and Mode
#		  Design and Organise Your Code Better Way
	
	Definition : Mode
		The most frequent number—that is, 
		the number that occurs the highest number of times.

READING AND CODING ASSIGNMENTS
___________________________________________________________________________
	Learn Linux Commands
		Please Install Linux

	Linux In Nutshell, Oreilly Publication




