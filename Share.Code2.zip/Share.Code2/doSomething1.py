# Generate Codes For Inventory Items In Store
codes = []
for gender in "MF":
	for size in "SMLX":
		if gender == "F" and size == "X":
			continue
		for color in "BGW":
			codes.append(gender + size + color)

print(codes)

