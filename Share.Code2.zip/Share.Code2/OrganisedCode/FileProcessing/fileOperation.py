
def calcualteWordsFrequency(sourceFile):
	print("\tOpening File(READ): {0}".format(sourceFile))
	inFile  = open(sourceFile, "r")
	wordCount = {}
	for line in inFile:
		words = line.lower().split()
		for word in words:
			wordCount[word] = wordCount.get(word, 0) + 1
	inFile.close()
	return wordCount

def writeWordsFrequency(wordCount, destinationFile):
	print("\tOpening File(WRITE): {0}".format(destinationFile))
	outFile = open(destinationFile, "w")

	for word, frequency in wordCount.items():
		line = word + "  " + str(frequency) + "\n"
		outFile.write(line)

	outFile.close()
