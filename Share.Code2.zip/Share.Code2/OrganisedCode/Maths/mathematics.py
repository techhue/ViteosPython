
def sum(*numbers):
	result = 0
	for number in numbers:
		result = result + number
	return result

def product(*numbers):
	result = 1
	for number in numbers:
		result = result * number
	return result

def average(*numbers):
	return sum(*numbers)/len(numbers)
