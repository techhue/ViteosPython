# Calculate Word Frequency In Paragaph
# Means How Many Number of Times Word is Coming In Paragraph
# Modify This Program To Add Following Features
#	Read Content From File
# 	Write Word and Word Frequency in Another File

from FileProcessing.fileOperation import *
import os

DataPath = '/Users/intelligene/Documents/ViteosPython/OrganisedCode/Data/'
sourceFile		= DataPath+"words.txt"
destinationFile	= DataPath+"words.frequency" 

currentPath = os.getcwd()
print("Current Path: {0}".format(currentPath) )

print(sourceFile)
print(destinationFile)
wordCount = calcualteWordsFrequency(sourceFile)
writeWordsFrequency(wordCount, destinationFile)

