from mathematics import *

def calculate(*numbers, **operation):
	sum_operation = operation.get("sum", None)
	product_operation = operation.get("product", None)
	average_operation = operation.get("average", None)
	
	result_sum = None
	result_product = None
	result_average = None
	if sum_operation:
		result_sum = sum(*numbers)

	if product_operation:
		result_product = product(*numbers)

	if average_operation:
		result_average = average(*numbers)

	return result_sum, result_product, result_average

print(sum(10, 20, 30))
print(sum(10, 20, 30, 40, 50))
print(product(10, 20, 30))
print(product(10, 20, 30, 40, 50))
print(average(10, 20, 30))
print(calculate(10, 20, 30, 40, 50, sum=True, product=True))


# def awesomeCalculator(operation, *numbers):
# 	return operation(*numbers)

# print( awesomeCalculator(sum, 10, 20, 30, 40, 50) )
# print( awesomeCalculator(product, 10, 20, 30, 40, 50) )
# print( awesomeCalculator(average, 10, 20, 30, 40, 50) )


	