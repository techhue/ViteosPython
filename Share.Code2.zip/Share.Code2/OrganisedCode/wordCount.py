# Calculate Word Frequency In Paragaph
# Means How Many Number of Times Word is Coming In Paragraph
# Modify This Program To Add Following Features
#	Read Content From File
# 	Write Word and Word Frequency in Another File

from FileProcessing.fileOperation import *
import os

sourceFile		="words.txt"
destinationFile	="words.frequency" 

currentPath = os.getcwd()
print("Current Path: {0}".format(currentPath) )

wordCount = calcualteWordsFrequency(sourceFile)
writeWordsFrequency(wordCount, destinationFile)

