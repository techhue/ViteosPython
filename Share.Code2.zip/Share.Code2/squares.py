
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squares = []

print(numbers)
for number in numbers:
	if number % 2 == 0:
		squares = squares + [ number * number ]

print(squares)
