# Calculate Word Frequency In Paragaph
# Means How Many Number of Times Word is Coming In Paragraph
# Modify This Program To Add Following Features
#	Read Content From File
# 	Write Word and Word Frequency in Another File

import os

sourceFile		="words.txt"
destinationFile	="words.frequency" 

currentPath = os.getcwd()
print("Current Path: {0}".format(currentPath) )

def calcualteWordsFrequency(sourceFile):
	print("\tOpening File(READ): {0}".format(sourceFile))
	inFile  = open(sourceFile, "r")
	wordCount = {}
	for line in inFile:
		words = line.lower().split()
		for word in words:
			wordCount[word] = wordCount.get(word, 0) + 1
	inFile.close()
	return wordCount

def writeWordsFrequency(wordCount, destinationFile):
	print("\tOpening File(WRITE): {0}".format(destinationFile))
	outFile = open(destinationFile, "w")

	for word, frequency in wordCount.items():
		line = word + "  " + str(frequency) + "\n"
		outFile.write(line)

	outFile.close()

wordCount = calcualteWordsFrequency(sourceFile)
writeWordsFrequency(wordCount, destinationFile)

