
def dummyFun(*args):
	print(args)

dummyFun()
dummyFun(1, 2)
dummyFun(1, 2, 3)
dummyFun(1, 2, 3, "Ding", "Dong")
#dummyFun(1, 2, 3, ding="Ding", dong="Dong")

def dummyFunction(**kwargs):
	print(kwargs)

dummyFunction()
dummyFunction(firstName="Ram", lastName="Singh")
dummyFunction(firstName="Ram", lastName="Singh", title = "Mr.")
dummyFunction(firstName="Ram", lastName="Singh", title = "Mr.", ding="DING", dong="DONG")

# Fixed Arugment, Default Arguments, Variable Number of Keyword-Value Arguments
def constructName1(firstName, *marks, **others):
	lastName 	= others.get("lastName", None)
	title 		= others.get("title", None)
	fatherName  = others.get("fatherName", None)

	name = firstName 
	if lastName != None:
		name = firstName+ " " + lastName 
	if  title != None:
		name = title + " " + name
	if fatherName != None:
		name = name + " " + fatherName

	totalMarks = 0
	for mark in marks:
		totalMarks = totalMarks + mark
	return name, totalMarks

def constructName(firstName, *marks, **others):
	lastName 	= others.get("lastName", "")
	title 		= others.get("title", "")
	fatherName  = others.get("fatherName", "")
	name = title + " " + firstName+ " " + lastName + " " + fatherName
	name = name.strip()

	totalMarks = 0
	for mark in marks:
		totalMarks = totalMarks + mark
	return name, totalMarks

print(constructName("Ram"))
print(constructName("Ram", lastName="Singh"))
print(constructName("Ram", lastName="Singh", title="Mr."))
print(constructName("Ram", lastName="Singh", title="Mr.", fatherName="Dashrath"))
print(constructName("Ram", lastName="Singh", title="Mr.", ding="DING", fatherName="Dashrath"))
print(constructName("Ram", 10, 20, 30, lastName="Singh", title="Mr." ))

# Return Multiple Values As Comma Seperated Values i.e. Tuple
def minMax(*numbers):
	minValue = numbers[0]
	maxValue = numbers[0]

	for number in numbers:
		if number < minValue:
			minValue = number
		elif number > maxValue:
			maxValue = number

	return minValue, maxValue

# (-10, 100)
# (-200, 1000)
# (-200, 2000)
values = minMax(10, 20, 20, -10, 100, 90)
print(values)
print("Minumum Value {0} and Maximum Value {1}".format(values[0], values[1]) )

values = minMax(10, 20, 20, -10, 100, 90, -100, -200, 1000, 0)
print("Minumum Value {0} and Maximum Value {1}".format(values[0], values[1]) )

values = minMax(10, 20, 2000, -10, 100, 90, -100, -200, 1000, 0, 80, 70, 11, 33)
print("Minumum Value {0} and Maximum Value {1}".format(values[0], values[1]) )


