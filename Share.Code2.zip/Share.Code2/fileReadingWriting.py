import os

sourceFile		="words.txt"
destinationFile	="words.output" 
currentPath = os.getcwd()

print("Current Path: {0}".format(currentPath) )

print("\tOpening File(READ): {0}".format(sourceFile))
inFile  = open( sourceFile, "r")
print("\tOpening File(WRITE): {0}".format(destinationFile))
outFile = open(destinationFile, "a")

for line in inFile:
	words = line.split()
	line = str(len(words)) + "  " + line
	outFile.write(line)

inFile.close()
outFile.close()

