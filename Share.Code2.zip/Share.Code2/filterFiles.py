
files = ["ding.html", "ting.htm", "ding.html", "Dong.HTML", "tong.c", "mong.java" ]

htmlFiles = []
for file in files:
	if file.lower().endswith((".html", ".htm")):
		htmlFiles.append(file)
print(htmlFiles)

#Set Compresension
htmlFiles = { file for file in files if file.lower().endswith((".htm", ".html")) }