import sys

# Type of first and second will be Python float
# 	Python float is C double i.e. It's Double Precision Floating Point Number

first  = 90.878789898978
second = 90.8787898989788989483984

if abs(first - second ) <= sys.float_info.epsilon:
	print("Floating Points Are Equal")
else:
	print("Floating Points Are UnEqual")

