# Calculate Word Frequency In Paragaph
# Means How Many Number of Times Word is Coming In Paragraph

content = """ding dong
		   ming mong mong mong mong mong
		   ting tong ting tong ting tong\n ping pong ping pong"""

# print("Lines Are...")
# lines = content.splitlines()
# for line in lines:
# 	print(line)

print("Words Are...")
words = content.split()
# uniquewords = set(words)

wordCount = {}
for word in words:
		# print(word, content.count(word))
		wordCount[word] = wordCount.get(word, 0) + 1

print("Frequency Of Words Are...")
print(wordCount)



