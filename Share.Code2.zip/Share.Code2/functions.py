
def product(numbers):
	result = 1
	for number in numbers:
		result = result * number
	return result

def factorial(number):
	result = 1
	for n in range(2, number+1):
		result = result * n
	return result

numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print("Sum of {0}: {1}".format(numbers, sum(numbers)) ) 
print("Product of {0}: {1}".format(numbers, product(numbers)) ) 
print("Factorial of {0}: {1}".format(4, factorial(4)) )


#Function Takes One Argument and Return Value is One
def square(number):
	return number * number

print("Square of {0} is: {1}".format(10, square(10)) )

#Function Takes Two Arguments and Return Value is One
def sumOld(value1, value2):
	return value1 + value2

print("Addtion of {0} and {1} is: {2}".format(10, 20, sumOld(10, 20)) )
print("Addtion of {0} and {1} is: {2}".format(10.9, 20.9, sumOld(10.9, 20.9)) )

#Function Takes One Argument and Return Value is One
# This One Arguments Itself is a Sequence

def sum(numbers):
	result = 0
	for number in numbers:
		result = result + number
	return result

numbers = (1, 2, 3, 4, 5)
print("Sum of {0}: {1}".format(numbers, sum(numbers)) ) 

numbers = [1, 2, 3, 4, 5, 6]
print("Sum of {0}: {1}".format(numbers, sum(numbers)) ) 

# numbers = 10
# print("Sum of {0}: {1}".format(numbers, sum(numbers)) ) 

# numbers = "DING DONG"
# print("Sum of {0}: {1}".format(numbers, sum(numbers)) ) 

# Default Arguments Means It Has Default Values
# While Calling These Functions Default Arguments Are Optional
def name(firstName, lastName="", title="Mr."):
	return title + " " + firstName + " " + lastName

print("Full Names Are:...")
print(name(firstName="Ram"))
print(name(firstName="Ram", title="Dear"))
print(name(firstName="Ram", lastName="Singh", title="Dear"))
print(name(firstName="Sita", title="Mrs."))


#numbers = (1, 2, 3, 4, 5)
#sumOnceMore(numbers)

# Function with Variable Numbers of Arguments
# Agurments Unpacking
def sumOnceMore(*numbers):
	result = 0
	for number in numbers:
		result = result + number
	return result

print( sumOnceMore(1, 2) )
print( sumOnceMore(2, 4, 5) )
print( sumOnceMore(10, 20, 30, 40, 50, 60) )

def dummyFunction(**kwargs):
	print(kwargs)

dummyFunction(1, 2, 3)

