# Calculaute Leap Years Between 1900 to 2000

# Leap Year Definition
# ________________________________________________________________
# Every year that is exactly divisible by four is a leap year, except for years that are exactly divisible by 100, but these centurial years are leap years if they are exactly divisible by 400. For example, the years 1700, 1800, and 1900 are not leap years, but the years 1600 and 2000 are


# Using While Loop
# year = 1900
# while year < 2001:
# 	if ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0 ):
# 		leapYears.append(year)
# 	year = year + 1

# print(leapYears)


# Using For Loop
leapYears = []
for year in range(1900, 2001):
	if ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0 ):
		leapYears.append(year)
print(leapYears)

# Using List Compreshension
leapYears = [ year for year in range(1900, 2001) if ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0 ) ]
print(leapYears)




