
value = 20

if value < 0 :
	print("It's Negative Value")
elif value == 0:
	print("It's Zero Value")
elif value > 0 and value < 100 :
	print("Positive and Less Than Hundred")
else:
	print("It's more than Hundred")

# result IS 0 if value < 0 else it is value
result = 0 if value < 0 else value

print(result)

while value < 100:
	value = value + 1

